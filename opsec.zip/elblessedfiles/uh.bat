@echo off
color 4
echo setting up vpn and opsec the vpn is mullvard tho
echo starting up...
echo done.. click any key whenever u are ready.
pause
python hack.py