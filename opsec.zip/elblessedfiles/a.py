import os #holy opsec
import subprocess
import sys
import time
import random
import colorama 
from colorama import Fore

def typewriter_effect(text, delay=0.05):
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print() 

text = [
    " ✓ sudo apt install opsec",
    " ✓ installing opsec...",
    " ✓ opsec is almost done installing...",
    " ✓ opsec is is sucessfully installed!",
    " ✓ setting up opsec",
    " ✓ Done...",
    " ⓘ mr.robot",
    " ☠ kali linux is the best distro",
    " </> welcome to hacktok brother",
    "===========================",
]
logo = """
                       .oooo.       .   oooo        
                     .dP""Y88b    .o8   `888        
 .oooo.o oooo    ooo       ]8P' .o888oo  888 .oo.   
d88(  "8  `88.  .8'      .d8P'    888    888P"Y88b  
`"Y88b.    `88..8'     .dP'       888    888   888  
o.  )88b    `888'    .oP     .o   888 .  888   888  
8""888P'     .8'     8888888888   "888" o888o o888o 
         .o..P'                                     
         `Y8P'
____________________________________________________
____________________________________________________  """
print (Fore.GREEN + logo)


#inputs
while True:
    print ("install opsec // hack // both")
    wdywtd = input ("what do you want to do?: ").strip().lower()


#functions
    if wdywtd == "opsec":
           for s in text:
            typewriter_effect (s)
    elif wdywtd == "hack":
        subprocess.Popen("start cmd /c uh.bat", shell=True )