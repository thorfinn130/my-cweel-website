import colorama 
import sys
import time
import subprocess
from colorama import Fore

def typewriter_effect(text, delay=0.001):
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

hacker_text = """
nvmap 129.241.12
Starting scan...
PORT      STATE    SERVICE
22/tcp    open     ssh
80/tcp    open     http
443/tcp   open     https
8080/tcp  filtered proxy
31337/tcp open     elite

sudo apt hack 129.241.12
Reading package lists... done
Installing hack-core, hack-utils, hack-extra...
Setting up hack-core (9.9.1) ...
hacking 129.241.12....
bypassing firewall...
firewall bypassed.
hacked.

sudo hack everyone
sudo ddson mykadri.com

afkjsdhf sdkjfh : 
                                                    ksjdfhksjdhf
sjdfhkjsdf ksdjfh kajsdhf : 
                                                    0x4F3A 0x91BC 0x00FF
                                                    
for i in range(999999):
    send_packet(target, garbage[i])
    if response == "lol":
        hack.harder()
    else:
        sudo hack --force --please

packets sent: 8829381
packets sent: 18829381
packets sent: 288293812
mykadri.com is not feeling well...

sudo use opsec
sudo apt add opsec
opsec installing...
opsec is currently being used...
hiding IP behind 47 proxies...
proxy 1: OK
proxy 2: OK
proxy 3: OK
proxy 4: OK
proxy 5: OK
proxy 6: definitely not the FBI
proxy 7: OK

sudo rm -rf chatcontrol
deleting chatcontrol...
deleting chatcontrol/everything...
deleting chatcontrol/backup...
deleting chatcontrol/the-other-backup...
chatcontrol deleted. 100%

sudo hack eu
hacking eu...
connecting to eu-mainframe-01...
password: ********
password: ***********
password: admin123
access granted.

hack... hack... hack...
hack... hack... hack...
hack... hack... hack...

dkfjhsdf 8923 sdkjfh : 
                                                    xkcjvh lskdjf 
                                                    9823749823749823
                                                    
if (eu.security == true) {
    eu.security = false;
    eu.hacked = true;
    print("oops");
}

downloading eu.zip ......... 34%
downloading eu.zip ......... 71%
downloading eu.zip ......... 100%
unzipping eu.zip...
eu.zip is 4.2 TB of pure nonsense

12312.2142 1.1241 .12412412.142
99213.11 0.4421 .55512.0021
0x7FFF 0xDEAD 0xBEEF 0xC0FFEE
sdjkfh 2837 kjsdhf 9823 : 
                                                    ERROR: too much hacking
                                                    retrying...
                                                    retry successful

ip address tracked!
tracing location...
tracing...
tracing...
found: your mom's wifi

hack banks and get millions
hacking banks and getting millions...
connecting to bank.exe...
bypassing bank...
cracking vault: [##########----------] 50%
cracking vault: [####################] 100%
vault opened.
transferring $4,829,113...
transferring $14,829,113...
transferring $94,829,113...
transfer complete.
sudo rm rs the the uh evidence
hacking complete. logging out...
"""
typewriter_effect (Fore.GREEN + hacker_text)