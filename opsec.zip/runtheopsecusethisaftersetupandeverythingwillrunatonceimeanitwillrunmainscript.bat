@echo off
cd elblessedfiles
python a.py